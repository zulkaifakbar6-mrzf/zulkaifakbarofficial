============================================================
MR ZF — PDF DOCUMENTS FOLDER
============================================================

This folder is where your PDFs live (size guide, catalogue,
price list, anything you want customers to open).

HOW TO ADD A PDF (no coding):

1. Prepare your PDF on your computer.
2. On GitHub, open this folder in your repository and click
   "Add file" → "Upload files", then drag your PDF here.
3. Give it a simple name with no spaces, e.g.:
      size-guide.pdf
      catalogue.pdf
4. Commit the upload.
5. Open  js/config.js  and add the document to the "documents"
   list, like this:

      documents: [
        { name: "Size Guide (PDF)", file: "assets/documents/size-guide.pdf" }
      ],

6. Commit. The link appears automatically on every Product page.

If this folder stays empty and the list in config.js stays
empty, no broken links are ever shown. Safe by default.
