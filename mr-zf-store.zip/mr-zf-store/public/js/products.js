/* ============================================================
   MR ZF — SPARE COPY of the product data (fallback)
   ------------------------------------------------------------
   The website normally reads data/products.json — that is the
   file you should edit (see README).

   This file is only used when the site is opened directly from
   your computer (double-clicking index.html), where the browser
   cannot fetch .json files. If you preview your site that way
   AND want to see your latest products locally, copy your
   changes into the list below as well.

   If you only ever edit on GitHub and check your live website,
   you can ignore this file completely.
   ============================================================ */

window.MRZF_PRODUCTS = [
  {
    "id": "MZ-001",
    "slug": "mr-zf-classic-shirt",
    "name": "Mr ZF Classic Shirt",
    "category": "Shirts",
    "description": "The piece Mr ZF is built around. A clean, structured everyday shirt with a comfortable regular fit — easy to dress up for the evening and easy to wear all day.",
    "price": 3499,
    "currency": "PKR",
    "sizes": [
      "S",
      "M",
      "L",
      "XL"
    ],
    "colors": [
      "Black",
      "White"
    ],
    "images": [
      "assets/images/products/mz-001.svg"
    ],
    "featured": true,
    "newArrival": true,
    "available": true
  },
  {
    "id": "MZ-002",
    "slug": "mr-zf-everyday-oxford-shirt",
    "name": "Mr ZF Everyday Oxford Shirt",
    "category": "Shirts",
    "description": "A softer, relaxed oxford woven for daily wear. Breathable, low-maintenance and cut slightly loose — the shirt you keep reaching for.",
    "price": 2999,
    "currency": "PKR",
    "sizes": [
      "S",
      "M",
      "L",
      "XL"
    ],
    "colors": [
      "Light Blue",
      "White"
    ],
    "images": [
      "assets/images/products/mz-002.svg"
    ],
    "featured": false,
    "newArrival": false,
    "available": true
  },
  {
    "id": "MZ-003",
    "slug": "mr-zf-essential-tee",
    "name": "Mr ZF Essential Tee",
    "category": "T-Shirts",
    "description": "A heavy-weight cotton tee with a clean silhouette and no loud branding. Holds its shape wash after wash — the foundation of an easy wardrobe.",
    "price": 1299,
    "currency": "PKR",
    "sizes": [
      "S",
      "M",
      "L",
      "XL"
    ],
    "colors": [
      "Black",
      "White",
      "Grey"
    ],
    "images": [
      "assets/images/products/mz-003.svg"
    ],
    "featured": true,
    "newArrival": false,
    "available": true
  },
  {
    "id": "MZ-004",
    "slug": "mr-zf-signature-tee",
    "name": "Mr ZF Signature Tee",
    "category": "T-Shirts",
    "description": "Our boxy signature fit with a small MR ZF mark across the chest. Understated, modern and made to be noticed without shouting.",
    "price": 1499,
    "currency": "PKR",
    "sizes": [
      "M",
      "L",
      "XL"
    ],
    "colors": [
      "Black",
      "Sand"
    ],
    "images": [
      "assets/images/products/mz-004.svg"
    ],
    "featured": false,
    "newArrival": true,
    "available": true
  },
  {
    "id": "MZ-005",
    "slug": "mr-zf-tailored-trousers",
    "name": "Mr ZF Tailored Trousers",
    "category": "Trousers",
    "description": "Sharp, tapered trousers with a pressed crease and a clean waistband. Smart enough for work, comfortable enough for everything after.",
    "price": 3999,
    "currency": "PKR",
    "sizes": [
      "30",
      "32",
      "34",
      "36",
      "38"
    ],
    "colors": [
      "Charcoal",
      "Beige"
    ],
    "images": [
      "assets/images/products/mz-005.svg"
    ],
    "featured": false,
    "newArrival": true,
    "available": true
  },
  {
    "id": "MZ-006",
    "slug": "mr-zf-comfort-chinos",
    "name": "Mr ZF Comfort Chinos",
    "category": "Trousers",
    "description": "A relaxed chino with a touch of stretch, cut for long days. Pairs with the Classic Shirt when you want to look put-together with zero effort.",
    "price": 3299,
    "currency": "PKR",
    "sizes": [
      "30",
      "32",
      "34",
      "36",
      "38"
    ],
    "colors": [
      "Navy",
      "Stone"
    ],
    "images": [
      "assets/images/products/mz-006.svg"
    ],
    "featured": false,
    "newArrival": false,
    "available": true
  },
  {
    "id": "MZ-007",
    "slug": "mr-zf-bomber-jacket",
    "name": "Mr ZF Bomber Jacket",
    "category": "Jackets",
    "description": "A minimal bomber with ribbed cuffs and hem, a smooth zip and a structure that keeps its shape. The layer that finishes the whole outfit.",
    "price": 6499,
    "currency": "PKR",
    "sizes": [
      "M",
      "L",
      "XL"
    ],
    "colors": [
      "Black",
      "Olive"
    ],
    "images": [
      "assets/images/products/mz-007.svg"
    ],
    "featured": true,
    "newArrival": false,
    "available": true
  },
  {
    "id": "MZ-008",
    "slug": "mr-zf-classic-leather-belt",
    "name": "Mr ZF Classic Leather Belt",
    "category": "Accessories",
    "description": "A full-grain leather belt with a brushed brass buckle. Simple, hard-wearing and finished by hand.",
    "price": 1899,
    "currency": "PKR",
    "sizes": [
      "One Size"
    ],
    "colors": [
      "Black",
      "Brown"
    ],
    "images": [
      "assets/images/products/mz-008.svg"
    ],
    "featured": false,
    "newArrival": false,
    "available": false
  }
];
