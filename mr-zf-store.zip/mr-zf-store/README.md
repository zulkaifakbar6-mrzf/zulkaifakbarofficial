# MR ZF — Official Website (Version 1)

**Brand:** Mr ZF
**Founder:** Zulkaif Akbar
**Contact:** zulkaifakbar6@gmail.com
**Currency:** PKR · **Market:** Pakistan

A premium, fast, mobile-first clothing catalogue website.
Customers browse → choose size/colour/quantity → order directly on **WhatsApp**.
Appointments run through **Google Calendar**. No accounts, no payments, no
databases in Version 1 — on purpose. Simple, safe, and honest.

> **Reality note:** the 8 products inside are **DEMO content** so you can see
> the website working. Replace them with your real products before launch.

---

## 1. Start Here — The Only 3 Things You Must Change

| # | What | Where | How |
|---|------|-------|-----|
| 1 | **WhatsApp number** | `public/js/config.js` → `whatsappNumber` | Replace `923XXXXXXXXX` with your real number: digits only, no `+`, no spaces. Example: `+92 300 1234567` → `"923001234567"` |
| 2 | **Booking link** | `public/js/config.js` → `bookingUrl` | Paste your Google Calendar booking link (section 8 below). Leave `""` for now — the site shows a friendly notice, never a broken link |
| 3 | **Founder photo** | `public/assets/images/founder/` | Add your portrait named exactly `zulkaif-akbar-founder.jpg`. The website picks it up automatically (a stylish placeholder shows until then) |

Everything else works out of the box.

---

## 2. What Each Folder Is

```
mr-zf-store/
├── README.md                  ← you are here
├── vercel.json                ← settings so Vercel deploys correctly (auto)
└── public/                    ← THE WEBSITE (this folder gets deployed)
    ├── index.html             Home page
    ├── shop.html              All products + search + filters
    ├── product.html           Product details + WhatsApp ordering
    ├── about.html             Brand + founder story
    ├── appointment.html       Google Calendar booking
    ├── contact.html           WhatsApp / Email / Appointment
    ├── shipping.html          Shipping policy (has [ADD YOUR …] boxes)
    ├── returns.html           Returns & exchange (has [ADD YOUR …] boxes)
    ├── privacy.html           Plain-language privacy notice
    ├── 404.html               "Page not found" page
    ├── robots.txt / sitemap.xml  Search engine files
    ├── css/style.css          All design/styling
    ├── js/config.js           ★ YOUR CONTROL PANEL — edit this
    ├── js/products.js         Spare offline copy of products (see §4)
    ├── js/app.js              Website behaviour (no need to touch)
    ├── data/products.json     ★ YOUR PRODUCT LIST — edit this
    └── assets/
        ├── images/brand/      Logo mark, favicon, social-share image
        ├── images/founder/    Your portrait goes here
        ├── images/products/   Product pictures
        └── documents/         Your PDFs (size guide etc.) — see folder README
```

**You normally only ever touch:** `js/config.js`, `data/products.json`,
`assets/images/products/`, `assets/documents/`, and your founder photo.
That's it.

---

## 3. How to Add a New Product (No Coding)

1. **Take a photo** of the product (square-ish or portrait works best).
2. On GitHub, open `public/assets/images/products/` → **Add file → Upload
   files** → drag your photo → name it simply, e.g. `mz-009.jpg` → Commit.
3. Open `public/data/products.json` → click the ✏️ pencil icon to edit.
4. **Duplicate** the last product block (everything from `{` to `},`)
   and paste it at the end of the `"products"` list.
5. Edit the copy:
   - `"id": "MZ-009"` ← must be **unique** (this is the product code)
   - `"name"`, `"description"`, `"price"`
   - `"category"` — use one that already exists (Shirts, T-Shirts,
     Trousers, Jackets, Accessories) so it appears in the right filter
   - `"sizes"` and `"colors"` — customers must pick from these
   - `"images": ["assets/images/products/mz-009.jpg"]` ← path to your photo
   - `"featured": true` → shows in Featured on the home page
   - `"newArrival": true` → shows in New Arrivals + gets a "New" badge
6. **Commit changes** (green button). Keep "Commit directly to main".
7. Wait ~1 minute → your live website updates automatically.

**Mark a product SOLD OUT:** change `"available": true` to
`"available": false` and commit. The product shows a Sold Out badge and
cannot be ordered.

⚠️ JSON is picky: keep the quotes `" "` and commas exactly like the demo
products. After editing, GitHub shows the file — if you see a red error,
undo your last change and commit again.

---

## 4. A Note on `js/products.js`

The website reads `data/products.json` — **that is the file you edit.**
The `js/products.js` file is a spare copy used only when someone opens the
website by double-clicking files on a computer (where browsers block
`.json` loading). If you only ever edit on GitHub and check your live
website, you can ignore `products.js` completely.

---

## 5. Putting It on GitHub (Browser Only — No Software Needed)

1. Create a free account at **github.com** (if you don't have one).
2. Click **+ → New repository** → name: `mr-zf-store` → set **Public** →
   tick *Add a README* is **not needed** (you have one) → **Create**.
3. On the empty repo page click **"uploading an existing file"**.
4. Open the `mr-zf-store` folder **on your computer**, select **everything
   inside it** (README.md, vercel.json, and the whole `public` folder) and
   drag them into the browser. GitHub keeps the folder structure.
5. Wait for all files to upload → type `first upload` → **Commit changes**.

*(Alternative: install the free "GitHub Desktop" app and drag the whole
folder in — same result, friendlier for big uploads.)*

---

## 6. Deploying on Vercel (Your Choice)

1. Create a free account at **vercel.com** (use *Sign up with GitHub* —
   it connects the two automatically).
2. Click **Add New → Project** → find `mr-zf-store` → **Import**.
3. Vercel auto-detects the settings from `vercel.json`
   (Framework Preset: **Other**, Output Directory: **public**).
   If it ever asks, set Output Directory to `public` manually.
4. Click **Deploy** → wait ~1 minute.
5. Your site is live at something like
   **`https://mr-zf-store.vercel.app`** 🎉

Every future commit to GitHub redeploys the website automatically.

> **⚠️ One honest warning about Vercel (worth 60 seconds):**
> Vercel's free **Hobby plan is officially for non-commercial, personal
> use**. A commercial clothing store doesn't fully fit those terms, and
> Vercel can restrict such projects. Options, fully your call:
> - **Start on Vercel anyway** while testing (many do; it's your decision),
> - or use **Cloudflare Pages**, whose free tier does allow business
>   static sites — the steps are almost identical (section 7).
> Either way, this website stays plain HTML/CSS/JS, so you can move hosts
> any time by reconnecting the same repository.

---

## 7. Alternative Free Host: Cloudflare Pages (Commercial-Friendly)

1. Create a free account at **dash.cloudflare.com**.
2. Left menu: **Workers & Pages → Create → Pages → Connect to Git**.
3. Connect GitHub → pick `mr-zf-store` → **Begin setup** with:
   - Production branch: `main`
   - Build command: `exit 0`
   - Build output directory: `public`
4. **Save and Deploy** → live at `https://mr-zf-store.pages.dev`.

Same automatic redeploys, free `*.pages.dev` address, and the free tier
is documented as suitable for business/static content.

---

## 8. Set Up Your Appointment System (Google Calendar)

1. On a computer, open **calendar.google.com** with your Gmail
   (`zulkaifakbar6@gmail.com`).
2. Click **Create → Appointment schedule**.
3. Suggested setup:
   - Title: `Mr ZF — Personal Shopping / Order Consultation`
   - Duration: 15 minutes
   - Your availability: e.g. Mon–Sat, 12:00 PM – 8:00 PM (your real routine)
   - Description: *"Book a short consultation with Mr ZF — product and
     size guidance, bulk orders, custom requirements, business enquiries."*
4. Save, then open the appointment page → **Share my booking link** → copy.
5. Paste it in `public/js/config.js` → `bookingUrl: "https://calendar.google.com/…"`.

The Appointment page then shows the live booking calendar **embedded**,
plus a backup "open in new tab" button. Bookings arrive as normal
Calendar events + email confirmations on your Gmail.

---

## 9. Going-Live Checklist

- [ ] `whatsappNumber` replaced in `js/config.js` — **then test every
      WhatsApp button once on your phone**
- [ ] Demo products replaced / prices corrected
- [ ] Founder photo added (`zulkaif-akbar-founder.jpg`)
- [ ] `[ADD YOUR …]` boxes filled in on `shipping.html` and `returns.html`
- [ ] `bookingUrl` connected (or the friendly notice is fine for launch)
- [ ] Social links added in `config.js` (leave `""` to hide an icon — never
      put a fake `#` link)
- [ ] `sitemap.xml` + `robots.txt` + the `og:url` / `canonical` lines in each
      page's `<head>` updated to your final domain
- [ ] Open the site on a phone — everything readable at small sizes

---

## 10. Security Rules (Please Keep These)

- Never put passwords, API keys or customer data in this repository.
- Never commit customers' phone numbers or addresses from your chats.
- Version 1 has **no** admin panel, payments or accounts by design — that's
  the safest possible starting point. A Phase-2 admin system (Supabase,
  with proper login and permissions) is documented below, only when sales
  justify the extra complexity.

---

## 11. Future Phase 2 (Documented — Deliberately NOT Built)

When orders become regular, you can upgrade to a real admin dashboard:
secure login, add/edit products from a browser, image uploads, order
records. The planned stack is **Supabase Free** (database + storage +
auth). Notes for that day: enable Row Level Security on every table,
never expose a service-role key in browser code, validate file types and
sizes on upload — and remember Supabase's free tier pauses inactive
projects. Version 1 stays deliberately simple and reliable until then.

---

## 12. Troubleshooting

| Symptom | Likely cause & fix |
|---|---|
| Page is completely unstyled | A file was uploaded outside the `public/` structure — re-check the folder tree in §2 |
| Products say "could not be loaded" | `data/products.json` has a JSON typo — check quotes/commas near your last edit |
| WhatsApp opens with a wrong number | `config.js` → `whatsappNumber` still has the `X` placeholder, or contains `+`/spaces |
| Product page says "couldn't find that piece" | The `?id=` in the URL doesn't match the product's `"id"` in products.json |
| Booking button says "not set up yet" | Expected — paste your Google Calendar link into `bookingUrl` |
| Changes not appearing live | Did you **Commit**? Wait a minute and hard-refresh (Ctrl+Shift+R) |
| New photo doesn't show | Check the path in `images` matches the uploaded filename exactly (case-sensitive!) |
